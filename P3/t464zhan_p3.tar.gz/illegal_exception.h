#include <iostream>

class illegal_exception {
};